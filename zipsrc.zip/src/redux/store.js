import { configureStore } from "@reduxjs/toolkit";
import wishlistslice from "./slice/wishlistslice";


const store =configureStore({
    reducer:{
         wishlistreducer:wishlistslice
    }
})

export default store